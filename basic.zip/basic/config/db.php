<?php

return [
	    'class' => 'yii\db\Connection',
	    'dsn' => 'mysql:host=mysql.scm.tees.ac.uk;dbname=q5126227',
	    'username' => 'q5126227',
	    'password' => 'jb*;L>}v?RJ5',
	    'charset' => 'utf8',
	];
